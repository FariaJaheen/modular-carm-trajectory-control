clc;
close all;
clear all;

%% c-arm + Table --> rigid tree model
c_arm_table_robot = rigidBodyTree(DataFormat="row");

%% c-arm
% c-arm base 
c_arm_base_body = rigidBody('CArm_Base');
setFixedTransform(c_arm_base_body.Joint, eye(4));  % fix c-arm base to world coordinate system origin 
addVisual(c_arm_base_body, "Mesh", "../Blender/outputs_rigid_tree_objects/c_arm_base_rigid_tree.stl");
addCollision(c_arm_base_body, "Mesh", "../Blender/outputs_rigid_tree_objects/c_arm_base_rigid_tree.stl");
addBody(c_arm_table_robot, c_arm_base_body, 'base');

% c-arm lateral body and joint
c_arm_lateral_body = rigidBody('CArm_Lateral');
c_arm_lateral_jnt = rigidBodyJoint('CArm_Lateral_jnt', 'prismatic');
c_arm_lateral_jnt.PositionLimits = [-0.5, 0.5];  % lateral joint limits in metres

% joint to parent
rot_c_arm_base_to_lat = eul2rotm([0, 90, 0]*(pi/180));  %ZYX
transf_c_arm_base_to_lat = eye(4);
transf_c_arm_base_to_lat(1:3, 1:3) = rot_c_arm_base_to_lat;

setFixedTransform(c_arm_lateral_jnt, transf_c_arm_base_to_lat);
c_arm_lateral_body.Joint = c_arm_lateral_jnt;
addVisual(c_arm_lateral_body, "Mesh", "../Blender/outputs_rigid_tree_objects/c_arm_lateral_rigid_tree.stl");
addCollision(c_arm_lateral_body, "Mesh", "../Blender/outputs_rigid_tree_objects/c_arm_lateral_rigid_tree.stl");
addBody(c_arm_table_robot, c_arm_lateral_body, "CArm_Base");

% c-arm vertical body and joint
c_arm_vertical_body = rigidBody('CArm_Vertical');
c_arm_vertical_jnt = rigidBodyJoint('CArm_Vertical_jnt', 'prismatic');
c_arm_vertical_jnt.PositionLimits = [0, 0.46];  % vertical joint limits in metres

rot_c_arm_lat_to_vert = eul2rotm([0, -90, 0]*(pi/180));  %ZYX
transl_c_arm_lat_to_ver = [-0.89, 0, 0];
transf_c_arm_lat_to_ver = eye(4);
transf_c_arm_lat_to_ver(1:3, 1:3) = rot_c_arm_lat_to_vert;
transf_c_arm_lat_to_ver(1:3, 4) = transl_c_arm_lat_to_ver;

setFixedTransform(c_arm_vertical_jnt, transf_c_arm_lat_to_ver);
c_arm_vertical_body.Joint = c_arm_vertical_jnt;
addVisual(c_arm_vertical_body, "Mesh", "../Blender/outputs_rigid_tree_objects/c_arm_vertical_object.stl");
addCollision(c_arm_vertical_body, "Mesh", "../Blender/outputs_rigid_tree_objects/c_arm_vertical_object.stl");
addBody(c_arm_table_robot, c_arm_vertical_body, "CArm_Lateral");

% c-arm wigwag body and joint
c_arm_wigwag_body = rigidBody('CArm_WigWag');
c_arm_wigwag_jnt = rigidBodyJoint('CArm_WigWag_jnt', 'revolute');
c_arm_wigwag_jnt.PositionLimits = [-10, 10]*(pi/180);  % wig-wag joint limits in radians
transf_c_arm_vertical_to_wigwag = trvec2tform([0, 0, 0.1]);
setFixedTransform(c_arm_wigwag_jnt, transf_c_arm_vertical_to_wigwag);
c_arm_wigwag_body.Joint = c_arm_wigwag_jnt;
addVisual(c_arm_wigwag_body, "Mesh", "../Blender/outputs_rigid_tree_objects/c_arm_wigwag_object.stl");
addCollision(c_arm_wigwag_body, "Mesh", "../Blender/outputs_rigid_tree_objects/c_arm_wigwag_object.stl");
addBody(c_arm_table_robot,c_arm_wigwag_body,"CArm_Vertical");

% c-arm horizontal body and joint
c_arm_horizontal_body = rigidBody('CArm_Horizontal');
c_arm_horizontal_jnt = rigidBodyJoint('CArm_Horizontal_jnt', 'prismatic');
c_arm_horizontal_jnt.PositionLimits = [0, 0.15];  % horizontal joint limits in metres

rot_c_arm_wigwag_to_horizontal = eul2rotm([0, 0, -90]*(pi/180));  %ZYX
transf_c_arm_wigwag_to_horizontal = eye(4);
transf_c_arm_wigwag_to_horizontal(1:3, 1:3) = rot_c_arm_wigwag_to_horizontal;

setFixedTransform(c_arm_horizontal_jnt, transf_c_arm_wigwag_to_horizontal);
c_arm_horizontal_body.Joint = c_arm_horizontal_jnt;
addVisual(c_arm_horizontal_body, "Mesh", "../Blender/outputs_rigid_tree_objects/c_arm_horizontal_object.stl");
addCollision(c_arm_horizontal_body, "Mesh", "../Blender/outputs_rigid_tree_objects/c_arm_horizontal_object.stl");
addBody(c_arm_table_robot,c_arm_horizontal_body,"CArm_WigWag");

% c-arm tilt body and joint
c_arm_tilt_body = rigidBody('CArm_Tilt');
c_arm_tilt_jnt = rigidBodyJoint('CArm_Tilt_jnt', 'revolute');
c_arm_tilt_jnt.PositionLimits = [-90, 270]*(pi/180); % tilt joint limits in radians

transf_c_arm_wigwag_to_tilt = trvec2tform([0, 0, 0.5]);
setFixedTransform(c_arm_tilt_jnt, transf_c_arm_wigwag_to_tilt);
c_arm_tilt_body.Joint = c_arm_tilt_jnt;
addVisual(c_arm_tilt_body, "Mesh", "../Blender/outputs_rigid_tree_objects/c_arm_tilt_object.stl");
addCollision(c_arm_tilt_body, "Mesh", "../Blender/outputs_rigid_tree_objects/c_arm_tilt_object.stl");
addBody(c_arm_table_robot,c_arm_tilt_body,"CArm_Horizontal");

% c-arm orbital body and joint
c_arm_orbital_body = rigidBody('CArm_Orbital');
c_arm_orbital_jnt = rigidBodyJoint('CArm_Orbital_jnt', 'revolute');
c_arm_orbital_jnt.PositionLimits = [-100, 100]*(pi/180); % orbital joint limits in radians

rot_c_arm_tilt_to_orbital = eul2rotm([-90, 0, 90]*(pi/180));  %ZYX
transl_c_arm_tilt_to_orbital = [0, 0, 1.0];
transf_c_arm_tilt_to_orbital = eye(4);
transf_c_arm_tilt_to_orbital(1:3, 1:3) = rot_c_arm_tilt_to_orbital;
transf_c_arm_tilt_to_orbital(1:3, 4) = transl_c_arm_tilt_to_orbital;

setFixedTransform(c_arm_orbital_jnt, transf_c_arm_tilt_to_orbital);
c_arm_orbital_body.Joint = c_arm_orbital_jnt;
addBody(c_arm_table_robot,c_arm_orbital_body,"CArm_Tilt");

% C-arm end-effector
c_arm_ee_body = rigidBody('CArm_EndEffector');
setFixedTransform(c_arm_ee_body.Joint, eye(4));  % fix c-arm base to world coordinate system origin 
addVisual(c_arm_ee_body,"Mesh", "../Blender/outputs/c_arm_C.stl");
addCollision(c_arm_ee_body,"Mesh", "../Blender/outputs_rigid_tree_objects/C_joint_1.stl");
addCollision(c_arm_ee_body,"Mesh", "../Blender/outputs_rigid_tree_objects/C_joint_2.stl");
addCollision(c_arm_ee_body,"Mesh", "../Blender/outputs_rigid_tree_objects/C_joint_3.stl");
addCollision(c_arm_ee_body,"Mesh", "../Blender/outputs_rigid_tree_objects/C_joint_4.stl");
addCollision(c_arm_ee_body,"Mesh", "../Blender/outputs_rigid_tree_objects/C_joint_5.stl");
addCollision(c_arm_ee_body,"Mesh", "../Blender/outputs_rigid_tree_objects/C_joint_6.stl");
addCollision(c_arm_ee_body,"Mesh", "../Blender/outputs_rigid_tree_objects/C_joint_7.stl");
addCollision(c_arm_ee_body,"Mesh", "../Blender/outputs_rigid_tree_objects/C_joint_8.stl");
addCollision(c_arm_ee_body,"Mesh", "../Blender/outputs_rigid_tree_objects/C_joint_9.stl");
addCollision(c_arm_ee_body,"Mesh", "../Blender/outputs_rigid_tree_objects/C_joint_10.stl");
addCollision(c_arm_ee_body,"Mesh", "../Blender/outputs_rigid_tree_objects/C_joint_11.stl");
addCollision(c_arm_ee_body,"Mesh", "../Blender/outputs_rigid_tree_objects/C_joint_12.stl");
addCollision(c_arm_ee_body,"Mesh", "../Blender/outputs_rigid_tree_objects/C_joint_13.stl");
addCollision(c_arm_ee_body,"Mesh", "../Blender/outputs_rigid_tree_objects/C_joint_14.stl");
addCollision(c_arm_ee_body,"Mesh", "../Blender/outputs_rigid_tree_objects/C_joint_15.stl");
addCollision(c_arm_ee_body,"Mesh", "../Blender/outputs_rigid_tree_objects/C_joint_16.stl");
addCollision(c_arm_ee_body,"Mesh", "../Blender/outputs_rigid_tree_objects/C_joint_17.stl");
addCollision(c_arm_ee_body,"Mesh", "../Blender/outputs_rigid_tree_objects/C_joint_18.stl");
addCollision(c_arm_ee_body,"Mesh", "../Blender/outputs_rigid_tree_objects/C_joint_19.stl");
addCollision(c_arm_ee_body,"Mesh", "../Blender/outputs_rigid_tree_objects/C_joint_20.stl");
addCollision(c_arm_ee_body,"Mesh", "../Blender/outputs_rigid_tree_objects/C_joint_21.stl");
addCollision(c_arm_ee_body,"Mesh", "../Blender/outputs_rigid_tree_objects/C_joint_22.stl");
addCollision(c_arm_ee_body,"Mesh", "../Blender/outputs_rigid_tree_objects/C_joint_23.stl");
addBody(c_arm_table_robot, c_arm_ee_body, 'CArm_Orbital');

%% Table
% Table base
table_base_body = rigidBody('Table_Base');
transf_c_arm_base_to_table_base = trvec2tform([0.4, 1.575, 0]);
setFixedTransform(table_base_body.Joint, transf_c_arm_base_to_table_base);  % connect table base to c-arm base
addVisual(table_base_body, "Mesh", "../Blender/outputs_rigid_tree_objects/table_wheels_base_object_1.stl");
addVisual(table_base_body, "Mesh", "../Blender/outputs_rigid_tree_objects/table_wheels_base_object_2.stl");
addCollision(table_base_body, "Mesh", "../Blender/outputs_rigid_tree_objects/table_wheels_base_object_1.stl");
addCollision(table_base_body, "Mesh", "../Blender/outputs_rigid_tree_objects/table_wheels_base_object_2.stl");
addBody(c_arm_table_robot, table_base_body, 'CArm_Base');

% Table vertical body and joint
table_vertical_body = rigidBody('Table_Vertical');
table_vertical_jnt = rigidBodyJoint('Table_Vertical_jnt', 'prismatic');
table_vertical_jnt.PositionLimits = [0, 0.36];

transf_table_base_to_vertical = trvec2tform([0, 0, 0.36]);
setFixedTransform(table_vertical_jnt, transf_table_base_to_vertical);
table_vertical_body.Joint = table_vertical_jnt;
addVisual(table_vertical_body, "Mesh", "../Blender/outputs_rigid_tree_objects/table_body_sphere_object_1.stl");
addVisual(table_vertical_body, "Mesh", "../Blender/outputs_rigid_tree_objects/table_body_sphere_object_2.stl");
addCollision(table_vertical_body, "Mesh", "../Blender/outputs_rigid_tree_objects/table_body_sphere_object_1.stl");
addCollision(table_vertical_body, "Mesh", "../Blender/outputs_rigid_tree_objects/table_body_sphere_object_2.stl");
addBody(c_arm_table_robot,table_vertical_body,"Table_Base");

% Table Trend body and joint
table_trend_body = rigidBody('Table_Trend');
table_trend_jnt = rigidBodyJoint('Table_Trend_jnt', 'fixed');
% table_trend_jnt.PositionLimits = [-30, 30]*(pi/180);

rot_table_vertical_to_trend = eul2rotm([0, 0, -90]*(pi/180));  %ZYX
transl_table_vertical_to_trend = [0, 0, 0.22];
transf_table_vertical_to_trend = eye(4);
transf_table_vertical_to_trend(1:3, 1:3) = rot_table_vertical_to_trend;
transf_table_vertical_to_trend(1:3, 4) = transl_table_vertical_to_trend;

setFixedTransform(table_trend_jnt, transf_table_vertical_to_trend);
table_trend_body.Joint = table_trend_jnt;
addBody(c_arm_table_robot,table_trend_body,"Table_Vertical");

% Table Tilt body and joint
table_tilt_body = rigidBody('Table_Tilt');
table_tilt_jnt = rigidBodyJoint('Table_Tilt_jnt', 'fixed');
% table_tilt_jnt.PositionLimits = [-20, 20]*(pi/180);

rot_table_trend_to_tilt = eul2rotm([-90, 0, 90]*(pi/180));  %ZYX
transf_table_trend_to_tilt = eye(4);
transf_table_trend_to_tilt(1:3, 1:3) = rot_table_trend_to_tilt;

setFixedTransform(table_tilt_jnt, transf_table_trend_to_tilt);
table_tilt_body.Joint = table_tilt_jnt;
addBody(c_arm_table_robot,table_tilt_body,"Table_Trend");

% Table Longitudinal body and joint
table_longitudinal_body = rigidBody('Table_Logitudinal');
table_longitudinal_jnt = rigidBodyJoint('Table_Longitudinal_jnt', 'prismatic');
table_longitudinal_jnt.PositionLimits = [0, 0.7]; 

transf_table_tilt_to_longitudinal = trvec2tform([0.025, 0, 0]);
setFixedTransform(table_longitudinal_jnt, transf_table_tilt_to_longitudinal);
table_longitudinal_body.Joint = table_longitudinal_jnt;
addBody(c_arm_table_robot,table_longitudinal_body,"Table_Tilt");

% Table Transverse body and joint
table_transverse_body = rigidBody('Table_Transverse');
table_transverse_jnt = rigidBodyJoint('Table_Transverse_jnt', 'fixed');
% table_transverse_jnt.PositionLimits = [-0.13, 0.13];

rot_table_longitudinal_to_transverse = eul2rotm([0, 0, 90]*(pi/180));  %ZYX
transl_table_longitudinal_to_transverse = [0, 0, 0.05];
transf_table_longitudinal_to_transverse= eye(4);
transf_table_longitudinal_to_transverse(1:3, 1:3) = rot_table_longitudinal_to_transverse;
transf_table_longitudinal_to_transverse(1:3, 4) = transl_table_longitudinal_to_transverse;

setFixedTransform(table_transverse_jnt, transf_table_longitudinal_to_transverse);
table_transverse_body.Joint = table_transverse_jnt;
addBody(c_arm_table_robot,table_transverse_body,"Table_Logitudinal");

% Table End-Effector
table_ee_body = rigidBody('Table_EndEffector');

rot_table_transverse_to_ee = eul2rotm([0, 0, -90]*(pi/180));  %ZYX
transl_table_transverse_to_ee = [0.075, 0, 0];
transf_table_transverse_to_ee = eye(4);
transf_table_transverse_to_ee(1:3, 1:3) = rot_table_transverse_to_ee;
transf_table_transverse_to_ee(1:3, 4) = transl_table_transverse_to_ee;
setFixedTransform(table_ee_body.Joint, transf_table_transverse_to_ee);
addVisual(table_ee_body, "Mesh", "../Blender/outputs/table_top_watertight.stl");
addCollision(table_ee_body, "Mesh", "../Blender/outputs/table_top_watertight.stl");
addBody(c_arm_table_robot, table_ee_body, 'Table_Transverse');

%% show details
showdetails(c_arm_table_robot);

%% visualize
% viztree = interactiveRigidBodyTree(c_arm_table_robot, Frames="on", MarkerBodyName='CArm_EndEffector');
% viztree.Configuration = config;

%% export robot
exportrobot(c_arm_table_robot, RobotName="C-arm", OutputFileName="c_arm_table_robot_8CT.urdf", ExportMesh=true);
